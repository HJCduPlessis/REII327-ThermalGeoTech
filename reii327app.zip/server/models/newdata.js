var mongoose = require('mongoose');
//Create a mongoose model
var NewData = mongoose.model('NewData',{
    Temperture: {
      type: Number
    },
    Current: {
      type: Number
    },
    SystemState: {
      type: Boolean
    },
    SystemPower: {
      type: Number
    },
    SendDataAt: {
      type: Number
    }
  // SystemState: {
  //    type: Boolean,
  //    require: true
  // },
  // SystemPower: {
  //   type: Boolean,
  //    require: true
  // },
  // SendDataAt: {
  //   type: Number,
  //   require: true
  // }
});

module.exports = {NewData};
