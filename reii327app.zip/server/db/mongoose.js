var mongoose = require('mongoose'); //712
//promisis
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/Reii327App',{useNewUrlParser: true});


module.exports = {mongoose};
