//loading in third party`s
const path = require('path');
const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const hbs = require('hbs'); // templing engine, reuseble mark-ups
//Handlebars is used.
const socketIO = require('socket.io');

 var {mongoose} = require('./db/mongoose');
var {mongoose} = require('./models/newdata');
 var {mongoose} = require('./models/users');
//
//Set path that will call the public files
const publicPath = path.join(__dirname, '../public');
const viewPath = path.join(__dirname, '../views/partials');
const port = process.env.PORT || 3000;
// Configure express app
var app = express();
// app.use(bodyParser.json();)
//creat a server using http
var server = http.createServer(app);
//Configure the server to use socket.io
var io = socketIO(server); // Return Web socket server. This is how we can communicate between the server and the client.

hbs.registerPartials(viewPath)
app.set('view engine', 'hbs') // let as set
app.use(express.static(publicPath)); // What the remote user have acces
// Listen on the port set-up
// Call a method
io.on('connection', (socket) => {
  console.log(`New user connected`);

  socket.on('disconnect', () => {
    console.log('User was disconnect');
  });
  socket.on('EmergencyShutDown', (ESD) => {
    console.log('EmergencyShutDown', ESD);
    });
    socket.on('DiagnodticEnvoked',(DED) => {
      console.log('DiagnodticEnvoked', DED);
  });
  socket.on('SelfTestEnvoked',(STE) => {
    console.log('SelfTestEnvoked', STE);
});
socket.on('AutoMaticMode',(AMM) => {
  console.log('AutoMaticMode', AMM);
});
socket.on('NewDataArrive',(NDA) =>{
  console.log(NDA);
});
socket.on('ChangeData',(CD) =>{
  console.log(CD);
});
}); //Lets register an event lisiner.
app.get('/Home',(req, res) => {
  res.render('Home.hbs', {
    pageTitle: 'Home Page',
    currentYear: new Date().getFullYear()
  });
});

app.get('/diagnostic',(req, res) => {
  res.render('diagnostic.hbs', {
    pageTitle: 'Diagnostic Page',
    currentYear: new Date().getFullYear()
  });
});

app.get('/history',(req, res) => {
  res.render('history.hbs', {
    pageTitle: 'History Page',
    currentYear: new Date().getFullYear()
  });
});

server.listen(port,() => {
  console.log(`Server is up on ${port}`);
});
